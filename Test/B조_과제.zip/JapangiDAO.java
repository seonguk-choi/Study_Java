package exam;

import java.util.Scanner;

public class JapangiDAO {
	Scanner sc = new Scanner(System.in);
	
	// 금액 입금 기능(dao1)
	int dao1(int cash) {
		while(true) {
			Scanner sc=new Scanner(System.in);
			System.out.println("돈넣어");
			cash=0;
			while(true) {
				try {
					cash= cash + Integer.parseInt(sc.nextLine());
					if(cash%10==0) {
					if(cash > 0) {
						System.out.println("돈 충분해");
						System.out.println("금액 : " + cash);
						return cash;
					}else {
						System.out.println("돈 부족해");
						continue;
					}
					}else {
						cash = 0;
						System.out.println("10원, 50원, 100원, 500원, 1000원 이상의 동전과 지폐만 사용가능해");
						System.out.println("다시 넣어");
					}
				}catch (Exception e) {
					System.out.println("돈넣으라고");
				}
			}
		}
	}
	
	// 음료 뽑기 기능(dao2)
	int dao2(JapangiDTO[] dto, int cash) {
		System.out.println("뽑으실 음료의 번호를 입력해주세요. (종료: -1)");
		for(int i = 0 ; i < dto.length ; i++) {
		System.out.println((i+1) + ". " + dto[i].getName() + " " +dto[i].getPrice() + "원  " +dto[i].getCount() + "개");
		}
		while(true) {
		int menu = Integer.parseInt(sc.nextLine());
			if(menu == -1) {
				return cash;
			}
		
		menu = menu - 1;
		
		
			if(dto[menu].getPrice() > cash) {
				System.out.println("금액이 부족합니다.");
				System.out.println("금액에 맞는 음료를 선택해주세요.");
			}else {
				System.out.println(dto[menu].getName() + "를 몇 개 뽑으시겠습니까?");
				while(true) {
					try {
				int count;
				int n;
				n = Integer.parseInt(sc.nextLine());
				if(n <= dto[menu].getCount() && cash >= n* dto[menu].getPrice() && n > 0) {
				System.out.println("선택하신 음료 " + dto[menu].getName() +" " + n + "개가 뽑혔습니다.");
				count = dto[menu].getCount() - n;
				
				dto[menu].setCount(count);
				cash = cash - n*dto[menu].getPrice();
				return cash;
					}else if(n > dto[menu].getCount() || n<=0){
						System.out.println("음료의 수량이 부족합니다.");
						System.out.println("뽑으실 음료의 번호를 입력해주세요.");
						for(int i = 0 ; i < dto.length ; i++) {
						System.out.println((i+1) + ". " + dto[i].getName() + " " +dto[i].getPrice() + "원  " +dto[i].getCount() + "개");
						}
						break;
					}else if(cash < n* dto[menu].getPrice()) {
						System.out.println("금액이 부족합니다.");
						System.out.println("금액에 맞는 개수를 입력해주세요.");
						continue;
					}
				}catch (Exception e) {
					System.out.println("올바른 개수를 입력해주세요.");
				}
				}
			}
		}
	}
	
	// 현금 반환 기능(dao3)
	void dao3 (int cash) { 
		  while(true) {
			  int cheon = 0;
			  int oback = 0;
			  int back = 0;
			  int osib = 0;
			  int sib = 0;
			  int sum = 0;
			  if(cash>1000) {
				  cheon = cash/1000;
				  cash = cash-(1000*cheon);
			  }
			  if(cash>500) {
				  oback = cash/500;
				  cash = cash-(500*oback);
			  }
			  if(cash>100) {
				  back = cash/100;
				  cash = cash-(100*back);
			  }
			  if(cash>50) {
				  osib = cash/50;
				  cash = cash-(50*osib);
			  }
			  if(cash>10) {
				  sib = cash/10;
				  cash = cash-(10*sib);
			  }
			 System.out.println("천원 : "+ cheon + "개 를 반환합니다.");
			 System.out.println("오백원 : "+ oback + "개 를 반환합니다.");
			 System.out.println("백원 : "+ back + "개 를 반환합니다.");
			 System.out.println("오십원 : "+ osib + "개 를 반환합니다.");
			 System.out.println("십원 : "+ sib + "개 를 반환합니다.");
			 sum =(1000*cheon) + (500*oback) + (100*back) + (50*osib) + (10*sib);
			 System.out.println("총" + sum + "원 반환 되었습니다.");
				  
			break;	  
		  } 
	}
	
	//관리자 id, pw 입력 기능(menager)
	boolean menager() {
		String id;
		String pw;
		System.out.println("id와 pw를 입력해주세요.");
		System.out.println("id");
		
		id = sc.nextLine();		
		if(id.equals("master")) {		
			System.out.println("pw");
			pw = sc.nextLine();		
			if(pw.equals("admin")) {
				System.out.println("로그인에 성공하였습니다.");
				return true;
				}else {
					System.out.println("pw가 틀렸습니다.");
					return false;
			}
		}else {
			System.out.println("id가 틀렸습니다.");
			return false;
		}
	}
	
	//음료 목록 보기 기능(menage0)
	boolean	menage0(JapangiDTO[] dto) {
		if(dto.length == 0) {
			System.out.println("자판기에 음료수가 없습니다.");
			return false;
		}
		System.out.println("현재 음료 목록 입니다.");
		for(int i = 0 ; i < dto.length ; i++) {
			System.out.println((i+1) + ". " + dto[i].getName() + " " +dto[i].getPrice() + "원  " +dto[i].getCount() + "개");
			}
		return true;
	}
	
	//음료 추가 기능(menage1)
	JapangiDTO[] menage1(JapangiDTO[] dto) {
		int n;
		System.out.println("신규 음료를 추가합니다.");
		System.out.println("음료를 몇 개 추가하시겠습니까?");
		n = Integer.parseInt(sc.nextLine());
		JapangiDTO[] dto1 = new JapangiDTO[dto.length+n]; 

		for(int i = 0 ; i < dto.length ; i++) {
			dto1[i] = new JapangiDTO(dto[i].getName(), dto[i].getPrice(), dto[i].getCount()); 
		}
		for(int i = 0 ; i < n ; i++) {
		dto1[dto.length+i] = new JapangiDTO();
		System.out.println("추가 할 음료의 이름을 입력해주세요.");
		dto1[dto.length+i].setName(sc.nextLine());
		System.out.println("추가 할 음료의 가격을 입력해주세요.");
		dto1[dto.length+i].setPrice(Integer.parseInt(sc.nextLine()));
		System.out.println("음료를 몇 개 넣으시겠습니까?");
		dto1[dto.length+i].setCount(Integer.parseInt(sc.nextLine()));
		}
		dto = new JapangiDTO[dto1.length];
		
		for(int i = 0 ; i < dto1.length ; i++) {
			dto[i] = new JapangiDTO(dto1[i].getName(), dto1[i].getPrice(), dto1[i].getCount()); 
		}
		System.out.println("새로운 음료가 추가되었습니다.");
		for(int i = 0 ; i < dto.length ; i++) {
			System.out.println((i+1) + ". " + dto[i].getName() + " " +dto[i].getPrice() + "원  " +dto[i].getCount() + "개");
			}
		return dto;
	}
	
	//음료 수정 기능(menage2)
	JapangiDTO[] menage2(JapangiDTO[] dto) {
		int menu;
		System.out.println("음료의 정보를 수정합니다.");
		while(true) {
		System.out.println("수정할 음료의 메뉴번호를 입력해주세요.(종료 -1)");
		
		
		for(int i = 0 ; i < dto.length ; i++) {
			System.out.println((i+1) + ". " + dto[i].getName() + " " +dto[i].getPrice() + "원  " +dto[i].getCount() + "개");
			}
		
		menu = Integer.parseInt(sc.nextLine());
		if(menu == -1) {
			System.out.println("최종 확인 된 메뉴 입니다.");
			for(int i = 0 ; i < dto.length ; i++) {
				System.out.println((i+1) + ". " + dto[i].getName() + " " +dto[i].getPrice() + "원  " +dto[i].getCount() + "개");
				}
			System.out.println("종료되었습니다.");
			return dto;
		}
		
		for(int i = 0; i < dto.length ; i++) {
			if(menu-1 == i) {
				System.out.println("선택하신 음료 " +dto[i].getName()+"의 무엇을 수정하시겠습니까?");
				System.out.println("1.음료의 이름, 2.음료의 가격 3.음료의 개수 4.메뉴 다시 고르기(종료 -1)");
				while(true) {
				menu = Integer.parseInt(sc.nextLine());
				if(menu == -1) {
					System.out.println("종료되었습니다.");
					return dto;
				}
				if(menu == 4) {
					break;
				}
				if(menu == 1) {
					System.out.println("음료의 이름을 수정합니다.");
					System.out.println("수정하실 이름을 입력해주세요.");
					String name = dto[i].getName();
					dto[i].setName(sc.nextLine()); 
					System.out.println("음료의 이름이 "+name+"에서 "+dto[i].getName()+"(으)로 수정되었습니다.");
					System.out.println("또 수정할 사항이 있으신가요?");
					System.out.println("1.음료의 이름, 2.음료의 가격 3.음료의 개수 4.메뉴 다시 고르기(종료 -1)");
						}
				if(menu == 2) {
					System.out.println("음료의 가격을 수정합니다.");
					System.out.println("수정할 가격을 입력해주세요.");
					int price = dto[i].getPrice();
					dto[i].setPrice(Integer.parseInt(sc.nextLine())); 
					System.out.println(dto[i].getName()+"의 가격이 "+price+"원 에서 "+dto[i].getPrice()+"원 으로 수정되었습니다.");
					System.out.println("또 수정할 사항이 있으신가요?");
					System.out.println("1.음료의 이름, 2.음료의 가격 3.음료의 개수 4.메뉴 다시 고르기(종료 -1)");
						}
				if(menu == 3 ) {
					System.out.println("음료의 개수를 변경합니다.");
					System.out.println("변경할 개수를 입력해주세요.");
					int count = dto[i].getCount();
					dto[i].setCount(Integer.parseInt(sc.nextLine())); 
					System.out.println(dto[i].getName()+"의 개수가 "+count+"개 에서 "+dto[i].getCount()+"개로 변경되었습니다.");
					System.out.println("또 수정할 사항이 있으신가요?");
					System.out.println("1.음료의 이름, 2.음료의 가격 3.음료의 개수 4.메뉴 다시 고르기(종료 -1)");
				}
					}
				break;
				}
			}
		}
	}
	
	//음료 삭제 기능(menage3)
	JapangiDTO[] menage3(JapangiDTO[] dto) {
		int menu;
		int n;
		while(true) {
		
		System.out.println("음료 데이터를 삭제합니다.");
		System.out.println("몇 번 메뉴의 음료 데이터를 삭제하시겠습니까?");
		for(int i = 0 ; i < dto.length ; i++) {
			System.out.println((i+1) + ". " + dto[i].getName() + " " +dto[i].getPrice() + "원  " +dto[i].getCount() + "개");
			}
		menu = Integer.parseInt(sc.nextLine());
		
		dto[menu-1] = new JapangiDTO();
		
		for(int i = 0 ; i < dto.length-menu ; i++) {
			if((menu-1)+(i+1)>dto.length) {
				break;
			}
			dto[(menu-1)+i].setName(dto[(menu-1)+(i+1)].getName());
			dto[(menu-1)+i].setPrice(dto[(menu-1)+(i+1)].getPrice());
			dto[(menu-1)+i].setCount(dto[(menu-1)+(i+1)].getCount());
			
		}
		JapangiDTO[] dto1 = new JapangiDTO[dto.length-1]; 
		
		for(int i = 0 ; i < dto1.length ; i++) {
			dto1[i] = new JapangiDTO();
			dto1[i].setName(dto[i].getName());
			dto1[i].setPrice(dto[i].getPrice());
			dto1[i].setCount(dto[i].getCount());
			}
		dto = new JapangiDTO[dto1.length];
		for(int i = 0 ; i < dto.length ; i++) {
			dto[i] = new JapangiDTO();
			dto[i].setName(dto1[i].getName());
			dto[i].setPrice(dto1[i].getPrice());
			dto[i].setCount(dto1[i].getCount());
			}
		System.out.println("선택하신 음료의 데이터가 삭제되었습니다.");
		System.out.println("최종 확인된 메뉴 입니다.");
		for(int i = 0 ; i < dto.length ; i++) {
			System.out.println((i+1) + ". " + dto[i].getName() + " " +dto[i].getPrice() + "원  " +dto[i].getCount() + "개");
			}
		System.out.println("추가로 삭제하시겠습니까? (실행 '1')(종료 '-1')");
			n = Integer.parseInt(sc.nextLine());
			if(n == 1) {
				continue;
			}
			if(n == -1) {
				System.out.println("종료되었습니다.");
				break;
			}
		}
		return dto;
	}
	JapangiDTO[] deleteProduct(JapangiDTO[] dto) {
		if(dto.length == 0) {
			System.out.println("음료의 데이터가 존재하지 않습니다.");
			return dto;
		}
		System.out.println("제거할 제품 번호를 입력하세요.");
		for (int i = 0; i < dto.length; i++) {
			System.out.println((i+1) + "번 " + dto[i].getName() +" "+ dto[i].getPrice() +"원 "+ dto[i].getCount()+"개");
		}
		int cnt = 0;
		int k = 0;
		JapangiDTO[] tempDto = new JapangiDTO[dto.length-1];
		while(true) {
			cnt = Integer.parseInt(sc.nextLine());
			try {
				if(cnt > 0 && cnt <= dto.length) {
					for (int i = 0; i < dto.length; i++) {
						if(dto[cnt-1] == dto[i]) {
							dto[i] = null;
							k--;
						} else {
							for (int j = k; j < dto.length-1 ; j++) {
								tempDto[k] = dto[i];								
							}
						}
						k++;
					}
				}else {
					System.out.println("다시 입력하세요.");
					continue;
				}
			} catch (Exception e) {
				System.out.println("숫자로 입력하세요.");
				continue;
			}
			for (int i = 0; i < tempDto.length; i++) {
				System.out.println((i+1) + "번 " + tempDto[i].getName() +" "+ tempDto[i].getPrice() +"원 "+ tempDto[i].getCount()+"개");
			}
			return tempDto;
		}
	}
}
