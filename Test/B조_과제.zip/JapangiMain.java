package exam;

import java.util.Scanner;

public class JapangiMain {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int cash = 0;
		int menu = 0;
		
		JapangiDTO[] dto = new JapangiDTO[3];
		dto[0] = new JapangiDTO("콜라", 800, 8);
		dto[1] = new JapangiDTO("사이다", 1000, 5);
		dto[2] = new JapangiDTO("환타", 900, 1);
		
		JapangiDAO dao = new JapangiDAO();
		
		System.out.println("자판기를 구동합니다.");
		while(true) {
			System.out.println("1. 자판기 이용, 2. 관리자 모드 (-1은 종료)");

			menu = Integer.parseInt(sc.nextLine());
			
			if(menu == -1) {
				System.out.println("프로그램을 종료합니다.");
				break;
			}
		if(menu == 1) {
			
			
		cash = dao.dao1(cash);
		
		cash = dao.dao2(dto, cash);
		
		dao.dao3(cash);
		
			}
		if(menu == 2) {
				if(dao.menager()) {
					System.out.println("관리자 모드를 실행합니다.");
					System.out.println("메뉴를 입력해주세요.");
					while(true){
					System.out.println("0. 현재 음료 목록 1. 음료 추가 2. 음료 수정 3. 음료 삭제 (종료: -1)");
					
					menu = Integer.parseInt(sc.nextLine());
					if(menu == -1) {
						System.out.println("종료되었습니다.");
						break;
					}
					if(menu == 0) {
						dao.menage0(dto);
						continue;
					}
					if(menu == 1) {
						dto = dao.menage1(dto);
						continue;
					}
					if(menu == 2) {
						dto = dao.menage2(dto);
						continue;
					}
					if(menu == 3) {
						dto = dao.deleteProduct(dto);
						continue;
					}
					}
				}
			}
		}
	}
}
